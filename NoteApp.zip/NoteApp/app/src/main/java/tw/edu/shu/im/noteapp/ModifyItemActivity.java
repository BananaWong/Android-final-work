package tw.edu.shu.im.noteapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class ModifyItemActivity extends AppCompatActivity {
    static final int NOTE_SPEECH = 2;
    static final int TITLE_SPEECH = 1;
    private int mIndex;
    private EditText mNoteEditText;
    private ImageView mNoteSpeechToText;
    private EditText mTitleEditText;
    private ImageView mTitleSpeechToText;
    private Button mUpdateButton;

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setContentView(R.layout.activity_modify_item);
        setTitle("更新項目");
        this.mIndex = getIntent().getIntExtra("index", 0);
        Item localItem = ItemManager.getItem(this.mIndex);
        this.mTitleEditText = ((EditText)findViewById(R.id.title));
        this.mNoteEditText = ((EditText)findViewById(R.id.note));
        this.mUpdateButton = ((Button)findViewById(R.id.button_update));
        this.mTitleEditText.setText(localItem.title);
        this.mNoteEditText.setText(localItem.note);
        this.mUpdateButton.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ItemManager.updateItem(ModifyItemActivity.this.mIndex, ModifyItemActivity.this.mTitleEditText.getEditableText().toString(), ModifyItemActivity.this.mNoteEditText.getEditableText().toString());
                Intent localInten = new Intent();
                localInten.putExtra("update", true);
                ModifyItemActivity.this.setResult(-1, localInten);
                ModifyItemActivity.this.finish();
            }
        });
        this.mTitleSpeechToText = (ImageView) findViewById(R.id.title_speech_to_text);
        this.mNoteSpeechToText = (ImageView) findViewById(R.id.note_speech_to_text);
        this.mTitleSpeechToText.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ModifyItemActivity.this.startSpeechToText(1);
            }
        });
        this.mNoteSpeechToText.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ModifyItemActivity.this.startSpeechToText(2);
            }
        });
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        if ((i == 2 || i == 1) && i2 == -1) {
            String str = (String) intent.getStringArrayListExtra("android.speech.extra.RESULTS").get(0);
            if (i == 1) {
                this.mTitleEditText.setText(str);
            } else {
                this.mNoteEditText.setText(str);
            }
        }
    }

    private void startSpeechToText(int i) {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        startActivityForResult(intent, i);
    }
}