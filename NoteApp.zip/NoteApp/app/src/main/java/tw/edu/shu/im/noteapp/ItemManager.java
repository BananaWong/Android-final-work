package tw.edu.shu.im.noteapp;

import android.os.Bundle;

import java.util.ArrayList;

public class ItemManager {
    private static ArrayList<Item> sItemList = new ArrayList();

    public static void addItem(String str, String str2) {
        Item item = new Item();
        item.title = str;
        item.note = str2;
        sItemList.add(item);
    }

    //public static ArrayList<Item> getAllItem() {
      //  return (ArrayList) sItemList.clone();
    //}
    public static ArrayList getAllItem() {
        return (ArrayList) sItemList.clone();
    }

    public static Item getItem(int i) {
        return (Item) sItemList.get(i);
    }

    public static void updateItem(int i, String str, String str2) {
        Item item = (Item) sItemList.get(i);
        item.title = str;
        item.note = str2;
        sItemList.remove(item);
        sItemList.add(i, item);
    }

    public static void deleteItem(int i) {
        sItemList.remove(i);
    }
}