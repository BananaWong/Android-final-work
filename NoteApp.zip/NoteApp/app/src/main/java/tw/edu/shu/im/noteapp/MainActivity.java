package tw.edu.shu.im.noteapp;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    private static final int ADD_ITEM = 1;
    private static final int UPDATE_ITEM = 2;
    private ArrayAdapter mAdapter;
    private ListView mListView;

    @SuppressLint("ResourceType")
    protected void onCreate(Bundle paramBundle)
    {
        super.onCreate(paramBundle);
        setContentView(R.layout.activity_main);
        setTitle("簡單記事APP 黃成");
        if (ItemManager.getAllItem().size() <= 0)
            new TestDataCreator().createTestData(30);


        this.mListView = (ListView) findViewById(R.id.listview);
        this.mAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, ItemManager.getAllItem());

        this.mListView.setAdapter(this.mAdapter);

        this.mListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
            {
                Intent localIntent = new Intent(MainActivity.this, ModifyItemActivity.class);
                localIntent.putExtra("index", paramAnonymousInt);
                MainActivity.this.startActivityForResult(localIntent, 2);
            }
        });

        this.mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener()
        {
            public boolean onItemLongClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, final int paramAnonymousInt, long paramAnonymousLong)
            {
                new AlertDialog.Builder(MainActivity.this).setTitle("刪除").setMessage("確定要刪除此項目嗎?").setPositiveButton("確定", new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
                    {
                        ItemManager.deleteItem(paramAnonymousInt);
                        MainActivity.this.mAdapter.clear();
                        MainActivity.this.mAdapter.addAll(ItemManager.getAllItem());
                        MainActivity.this.mAdapter.notifyDataSetChanged();
                    }
                }).setNegativeButton("取消", null).show();
                return true;
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu paramMenu)
    {
        getMenuInflater().inflate(R.menu.main_activity_menu, paramMenu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem paramMenuItem)
    {
        if (paramMenuItem.getItemId() == R.id.menu_add)
        {
            Log.d("Menu", "點下新增按鈕");
            startActivityForResult(new Intent(this, AddItemActivity.class), 1);
            return true;
        }
        return super.onOptionsItemSelected(paramMenuItem);
    }
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1 && i2 == -1) {
            if (intent.getBooleanExtra("update", false)) {
                this.mAdapter.clear();
                this.mAdapter.addAll(ItemManager.getAllItem());
                this.mAdapter.notifyDataSetChanged();
            }
        } else if (i == 2 && i2 == -1) {
            this.mAdapter.clear();
            this.mAdapter.addAll(ItemManager.getAllItem());
            this.mAdapter.notifyDataSetChanged();
        }

    }

}