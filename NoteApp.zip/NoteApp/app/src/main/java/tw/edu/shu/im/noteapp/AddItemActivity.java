package tw.edu.shu.im.noteapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;

public class AddItemActivity extends AppCompatActivity {
    static final int NOTE_SPEECH = 2;
    static final int TITLE_SPEECH = 1;
    private EditText mNoteEditText;
    private ImageView mNoteSpeechToText;
    private EditText mTitleEditText;
    private ImageView mTitleSpeechToText;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_add_item);

        setTitle("新增項目");

        this.mTitleEditText = (EditText) findViewById(R.id.title);
        this.mNoteEditText = (EditText) findViewById(R.id.note);
        this.mTitleSpeechToText = (ImageView) findViewById(R.id.title_speech_to_text);
        this.mNoteSpeechToText = (ImageView) findViewById(R.id.note_speech_to_text);

        this.mTitleSpeechToText.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AddItemActivity.this.startSpeechToText(1);
            }
        });
        this.mNoteSpeechToText.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AddItemActivity.this.startSpeechToText(2);
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_activity_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != R.id.menu_save) {
            return super.onOptionsItemSelected(menuItem);
        }
        Log.d("Menu", "點下儲存按鈕");
        ItemManager.addItem(this.mTitleEditText.getEditableText().toString(), this.mNoteEditText.getEditableText().toString());
       Intent data = new Intent();
        data.putExtra("update", true);
        //menuItem.putExtra("update", true);
        setResult(-1, data);
        finish();
        return true;
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        if ((i == 2 || i == 1) && i2 == -1) {
            String str = (String) intent.getStringArrayListExtra("android.speech.extra.RESULTS").get(0);
            if (i == 1) {
                this.mTitleEditText.setText(str);
            } else {
                this.mNoteEditText.setText(str);
            }
        }
    }

    private void startSpeechToText(int i) {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        startActivityForResult(intent, i);
    }
}